package com.example.demo.unitTest;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;
import com.example.demo.dto.LeaveRequestDto;
import com.example.demo.entity.*;
import com.example.demo.entity.enums.*;
import com.example.demo.exception.*;
import com.example.demo.repo.*;
import com.example.demo.service.impl.EmployeeServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@SpringBootTest
class EmployeeServiceTest {



    @InjectMocks
    private EmployeeServiceImpl employeeService;

    @Mock
    private WorkProfileDataRepo profileRepo;

    @Mock
    private CalculatedPayrollDataRepo payrollRepo;

    @Mock
    private LeaveRequestRepo leaveRequestRepo;

    private WorkProfileData testEmp;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        testEmp = new WorkProfileData(1, "Alice", "Wonder", Gender.female, "alice@example.com",
                "pass123", "HR", new Date(), "1234567890", "Wonderland", status.active, roles.Employee);
    }

    @Test
    public void testUpdateOwnProfile_Success() {
        WorkProfileData updateData = new WorkProfileData();
        updateData.setContactNumber("8888888888");
        updateData.setAddress("New Street");

        when(profileRepo.findById(1)).thenReturn(Optional.of(testEmp));

        employeeService.updateOwnProfile(1, updateData);

        verify(profileRepo).save(argThat(emp ->
                emp.getContactNumber().equals("8888888888") &&
                emp.getAddress().equals("New Street")
        ));
    }

    @Test
    public void testUpdateOwnProfile_NotFound() {
        when(profileRepo.findById(2)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () ->
                employeeService.updateOwnProfile(2, new WorkProfileData()));
    }

    @Test
    public void testGetPayrolls_Success() {
        when(profileRepo.existsById(1)).thenReturn(true);
        when(payrollRepo.findByEmpId(1)).thenReturn(List.of(new CalculatedPayrollData()));
        List<CalculatedPayrollData> result = employeeService.getpayrolls(1);
        assertEquals(1, result.size());
    }

    @Test
    public void testGetPayrolls_EmployeeNotFound() {
        when(profileRepo.existsById(10)).thenReturn(false);
        assertThrows(ResourceNotFoundException.class, () -> employeeService.getpayrolls(10));
    }

    @Test
    public void testApplyLeave_Success() {
        LeaveRequestDto dto = new LeaveRequestDto();
        dto.setEmployeeId(1);
        dto.setLeaveType(LeaveType.Sick);
        dto.setReason("Fever");
        dto.setStartDate(LocalDate.now().plusDays(1));
        dto.setEndDate(LocalDate.now().plusDays(3));

        when(profileRepo.findById(1)).thenReturn(Optional.of(testEmp));

        String result = employeeService.applyLeave(dto);

        assertEquals("Leave applied successfully!", result);
        verify(leaveRequestRepo).save(any(LeaveRequest.class));
    }

    @Test
    public void testApplyLeave_PastStartDate_ThrowsError() {
        LeaveRequestDto dto = new LeaveRequestDto();
        dto.setEmployeeId(1);
        dto.setStartDate(LocalDate.now().minusDays(1));
        dto.setEndDate(LocalDate.now());
        dto.setLeaveType(LeaveType.Sick);
        dto.setReason("Backdated");

        when(profileRepo.findById(1)).thenReturn(Optional.of(testEmp));

        assertThrows(IllegalArgumentError.class, () -> employeeService.applyLeave(dto));
    }

    @Test
    public void testApplyLeave_EndBeforeStart_ThrowsError() {
        LeaveRequestDto dto = new LeaveRequestDto();
        dto.setEmployeeId(1);
        dto.setStartDate(LocalDate.now().plusDays(2));
        dto.setEndDate(LocalDate.now().plusDays(1));
        dto.setLeaveType(LeaveType.Sick);
        dto.setReason("Invalid range");

        when(profileRepo.findById(1)).thenReturn(Optional.of(testEmp));

        assertThrows(IllegalArgumentError.class, () -> employeeService.applyLeave(dto));
    }

    @Test
    public void testShowLeaveRecord() {
        when(leaveRequestRepo.findByEmployeeId(1)).thenReturn(List.of(new LeaveRequest()));
        List<LeaveRequest> records = employeeService.showLeaveRecord(1);
        assertEquals(1, records.size());
    }

    @Test
    public void testAuthenticate_Success() {
        when(profileRepo.findByEmailIgnoreCaseAndPassword("alice@example.com", "pass123"))
                .thenReturn(testEmp);

        WorkProfileData result = employeeService.authenticate("alice@example.com", "pass123");
        assertEquals(testEmp.getEmpId(), result.getEmpId());
    }

    @Test
    public void testAuthenticate_Failure() {
        when(profileRepo.findByEmailIgnoreCaseAndPassword("wrong@example.com", "wrong"))
                .thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () ->
                employeeService.authenticate("wrong@example.com", "wrong"));
    }
}

