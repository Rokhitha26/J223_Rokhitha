package com.example.demo.unitTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.example.demo.entity.*;
import com.example.demo.entity.enums.*;
import com.example.demo.exception.*;
import com.example.demo.repo.LeaveRequestRepo;
import com.example.demo.repo.WorkProfileDataRepo;
import com.example.demo.service.impl.ManagerServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class ManagerServiceTest {

    @InjectMocks
    private ManagerServiceImpl managerService;

    @Mock
    private LeaveRequestRepo leaveRequestRepo;

    @Mock
    private WorkProfileDataRepo workProfileRepo;

    private LeaveRequest mockLeave;
    private WorkProfileData mockManager;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        mockLeave = new LeaveRequest();
        mockLeave.setRequestId(1);
        mockLeave.setStatus(LeaveStatus.Pending);

        mockManager = new WorkProfileData();
        mockManager.setEmpId(10);
        mockManager.setEmail("manager@example.com");
        mockManager.setPassword("secure123");
        mockManager.setRole(roles.Manager);
    }

    @Test
    public void testApproveLeaveRequest_Accept_Success() {
        when(leaveRequestRepo.findByRequestIdAndStatus(1, LeaveStatus.Pending))
                .thenReturn(Optional.of(mockLeave));

        managerService.approveLeaveRequest(1, "ACCEPT");

        assertEquals(LeaveStatus.Approved, mockLeave.getStatus());
        verify(leaveRequestRepo).save(mockLeave);
    }

    @Test
    public void testApproveLeaveRequest_Reject_Success() {
        when(leaveRequestRepo.findByRequestIdAndStatus(1, LeaveStatus.Pending))
                .thenReturn(Optional.of(mockLeave));

        managerService.approveLeaveRequest(1, "REJECT");

        assertEquals(LeaveStatus.Rejected, mockLeave.getStatus());
        verify(leaveRequestRepo).save(mockLeave);
    }

    @Test
    public void testApproveLeaveRequest_InvalidAction_ThrowsError() {
        when(leaveRequestRepo.findByRequestIdAndStatus(1, LeaveStatus.Pending))
                .thenReturn(Optional.of(mockLeave));

        assertThrows(IllegalArgumentError.class, () ->
                managerService.approveLeaveRequest(1, "HOLD"));
    }

    @Test
    public void testApproveLeaveRequest_NotFound_ThrowsError() {
        when(leaveRequestRepo.findByRequestIdAndStatus(99, LeaveStatus.Pending))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () ->
                managerService.approveLeaveRequest(99, "ACCEPT"));
    }

    @Test
    public void testShowPendingLeaveRequest() {
        List<LeaveRequest> mockList = List.of(mockLeave);
        when(leaveRequestRepo.findByStatus(LeaveStatus.Pending)).thenReturn(mockList);

        List<LeaveRequest> result = managerService.showPendingLeaveRequest();

        assertEquals(1, result.size());
        assertEquals(LeaveStatus.Pending, result.get(0).getStatus());
    }

    @Test
    public void testAuthenticate_Success() {
        when(workProfileRepo.findByEmailIgnoreCaseAndPassword("manager@example.com", "secure123"))
                .thenReturn(mockManager);

        WorkProfileData result = managerService.authenticate("manager@example.com", "secure123");

        assertEquals(mockManager.getEmpId(), result.getEmpId());
    }

    @Test
    public void testAuthenticate_InvalidCredentials() {
        when(workProfileRepo.findByEmailIgnoreCaseAndPassword("invalid@example.com", "wrong"))
                .thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () ->
                managerService.authenticate("invalid@example.com", "wrong"));
    }

}
