package com.example.demo.unitTest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import com.example.demo.entity.enums.roles;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import com.example.demo.entity.*;
import com.example.demo.repo.*;
import com.example.demo.service.impl.PayrollServiceImpl;
import com.example.demo.exception.ResourceNotFoundException;

public class PayrollServiceImplTest {

    @InjectMocks
    private PayrollServiceImpl payrollService;

    @Mock
    private PayrollAuditsRepo payrollRepo;

    @Mock
    private WorkProfileDataRepo profileRepo;

    @Mock
    private CalculatedPayrollDataRepo payrollDataRepo;

    @Mock
    private AdminPayrollConfigRepo configRepo;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testTriggerPayrollForEmployee_Success() {
        int adminId = 1;
        int empId = 101;

        WorkProfileData mockEmployee = new WorkProfileData();
        mockEmployee.setEmpId(empId);
        mockEmployee.setFirstName("John");
        mockEmployee.setLastName("Doe");
        mockEmployee.setDepartment("IT");
        mockEmployee.setRole(roles.Employee);

        AdminPayrollConfig mockConfig = new AdminPayrollConfig();
        mockConfig.setSalary(50000);
        mockConfig.setHraPercent(20);
        mockConfig.setPfPercent(12);
        mockConfig.setBonusPercent(10);
        mockConfig.setSpecialAllowancePercent(5);
        mockConfig.setProfessionalTax(200);

        when(profileRepo.findById(empId)).thenReturn(Optional.of(mockEmployee));
        when(configRepo.findByRoles(roles.Employee)).thenReturn(Optional.of(mockConfig));

        String result = payrollService.triggerPayrollForEmployee(adminId, empId);

        verify(payrollRepo, times(1)).save(any(PayrollAudits.class));
        verify(payrollDataRepo, times(1)).save(any(CalculatedPayrollData.class));

        assertEquals("Payroll generated successfully for Employee ID: " + empId, result);
    }

    @Test
    public void testTriggerPayrollForEmployee_EmployeeNotFound() {
        int adminId = 1;
        int empId = 999;

        when(profileRepo.findById(empId)).thenReturn(Optional.empty());

        ResourceNotFoundException thrown = org.junit.jupiter.api.Assertions.assertThrows(
            ResourceNotFoundException.class,
            () -> payrollService.triggerPayrollForEmployee(adminId, empId)
        );

        assertEquals("Employee not found", thrown.getMessage());
    }

    @Test
    public void testTriggerPayrollForEmployee_ConfigNotFound() {
        int adminId = 1;
        int empId = 101;

        WorkProfileData mockEmployee = new WorkProfileData();
        mockEmployee.setEmpId(empId);
        mockEmployee.setRole(roles.Employee);

        when(profileRepo.findById(empId)).thenReturn(Optional.of(mockEmployee));
        when(configRepo.findByRoles(roles.Employee)).thenReturn(Optional.empty());

        ResourceNotFoundException thrown = org.junit.jupiter.api.Assertions.assertThrows(
            ResourceNotFoundException.class,
            () -> payrollService.triggerPayrollForEmployee(adminId, empId)
        );

        assertEquals("No such roles exist", thrown.getMessage());
    }
}
