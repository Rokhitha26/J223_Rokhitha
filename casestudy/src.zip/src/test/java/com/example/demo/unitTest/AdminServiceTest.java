package com.example.demo.unitTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.dto.WorkProfileDataDto;
import com.example.demo.entity.*;
import com.example.demo.entity.enums.Gender;
import com.example.demo.entity.enums.roles;
import com.example.demo.entity.enums.status;
import com.example.demo.exception.DuplicateEmailException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repo.*;
import com.example.demo.service.EmailService;
import com.example.demo.service.impl.AdminServiceImpl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
@SpringBootTest
class AdminServiceTest {


    @InjectMocks
    private AdminServiceImpl adminService;

    @Mock
    private WorkProfileDataRepo profileRepo;

    @Mock
    private AdminPayrollConfigRepo payrollConfigRepo;

    @Mock
    private CalculatedPayrollDataRepo payrollRepo;

    @Mock
    private EmailService emailService;

    private WorkProfileData employee;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        employee = new WorkProfileData(1, "John", "Doe", Gender.male, "john@example.com", "pass123",
                "HR", new Date(), "9999999999", "123 Street", status.active, roles.Employee);
    }

    @Test
    public void testAddEmployee_Success() {
        when(profileRepo.existsByEmail(employee.getEmail())).thenReturn(false);
        when(profileRepo.save(any())).thenReturn(employee);

        adminService.addEmployee(employee);

        verify(emailService, times(1)).sendEmployeeWelcomeEmail(
                eq(employee.getEmail()), eq(employee.getEmpId()), eq(employee.getFirstName()));
    }

    @Test
    public void testAddEmployee_EmailAlreadyExists() {
        when(profileRepo.existsByEmail(employee.getEmail())).thenReturn(true);

        assertThrows(DuplicateEmailException.class, () -> adminService.addEmployee(employee));
    }

    @Test
    public void testDeleteEmployee_Success() {
        when(profileRepo.findById(1)).thenReturn(Optional.of(employee));
        adminService.deleteEmployee(1);
        verify(profileRepo, times(1)).delete(employee);
    }

    @Test
    public void testDeleteEmployee_NotFound() {
        when(profileRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> adminService.deleteEmployee(1));
    }

    @Test
    public void testGetAllEmployees() {
        when(profileRepo.findAll()).thenReturn(List.of(employee));
        List<WorkProfileDataDto> result = adminService.getAllEmployees();
        assertEquals(1, result.size());
        assertEquals("John", result.get(0).getFirstName());
    }

    @Test
    public void testAuthenticate_Success() {
        when(profileRepo.findByEmailIgnoreCaseAndPassword("john@example.com", "pass123")).thenReturn(employee);
        WorkProfileData result = adminService.authenticate("john@example.com", "pass123");
        assertEquals("John", result.getFirstName());
    }

    @Test
    public void testAuthenticate_Failure() {
        when(profileRepo.findByEmailIgnoreCaseAndPassword("john@example.com", "wrongpass")).thenReturn(null);
        assertThrows(ResourceNotFoundException.class, () ->
                adminService.authenticate("john@example.com", "wrongpass"));
    }

    @Test
    public void testUpdateEmployeeByAdmin_Success() {
        WorkProfileData updated = new WorkProfileData(1, "Jane", "Smith", Gender.female,
                "jane@example.com", "newpass", "Finance", new Date(), "8888888888",
                "New Address", status.inactive, roles.Manager);

        when(profileRepo.findById(1)).thenReturn(Optional.of(employee));
        adminService.updateEmployeeByAdmin(updated);
        verify(profileRepo, times(1)).save(any());
    }

    @Test
    public void testGetEmployeeById_Success() {
        when(profileRepo.findById(1)).thenReturn(Optional.of(employee));
        WorkProfileData result = adminService.getEmployeeById(1);
        assertEquals("John", result.getFirstName());
    }

    @Test
    public void testGetEmployeeById_NotFound() {
        when(profileRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> adminService.getEmployeeById(1));
    }

    @Test
    public void testPayrollTrigger() {
        LocalDate today = LocalDate.now();
        List<CalculatedPayrollData> data = new ArrayList<>();
        when(payrollRepo.findByDate(today)).thenReturn(data);
        List<CalculatedPayrollData> result = adminService.payrollTrigger(today);
        assertEquals(0, result.size());
    }

    @Test
    public void testConfigPayrollData_UpdateSuccess() {
        AdminPayrollConfig existing = new AdminPayrollConfig();
        existing.setRoles(roles.Employee);

        AdminPayrollConfig newConfig = new AdminPayrollConfig();
        newConfig.setRoles(roles.Employee);
        newConfig.setSalary(50000);

        when(payrollConfigRepo.findByRoles(roles.Employee)).thenReturn(Optional.of(existing));

        String result = adminService.configPayrollData(newConfig);
        assertTrue(result.contains("Payroll configuration updated successfully"));
    }

    @Test
    public void testConfigPayrollData_NoRoleGiven() {
        AdminPayrollConfig config = new AdminPayrollConfig();
        String result = adminService.configPayrollData(config);
        assertEquals("Error: Role is required for payroll configuration update.", result);
    }

    @Test
    public void testConfigPayrollData_NoExistingConfig() {
        AdminPayrollConfig config = new AdminPayrollConfig();
        config.setRoles(roles.Manager);
        when(payrollConfigRepo.findByRoles(roles.Manager)).thenReturn(Optional.empty());

        String result = adminService.configPayrollData(config);
        assertTrue(result.contains("No existing configuration found"));
    }

    @Test
    public void testGetCurrentPayrollConfiguredData() {
        List<AdminPayrollConfig> configs = new ArrayList<>();
        when(payrollConfigRepo.findAll()).thenReturn(configs);
        List<AdminPayrollConfig> result = adminService.getCurrentPayrollConfiguredData();
        assertEquals(0, result.size());
    }
}
