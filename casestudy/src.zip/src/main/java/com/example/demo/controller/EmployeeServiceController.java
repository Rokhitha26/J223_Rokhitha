package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.LeaveRequestDto;
import com.example.demo.entity.CalculatedPayrollData;
import com.example.demo.entity.LeaveRequest;
import com.example.demo.entity.WorkProfileData;
import com.example.demo.security.JwtUtil;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/api/employee")
@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeServiceController {

	@Autowired
	private EmployeeService employeeService;
	
    @Autowired
    private JwtUtil jwtUtil;
	
	@PutMapping("updateProfile/{empId}")
	public ResponseEntity<Map<String, String>> updateOwnProfile(
	        @PathVariable int empId,
	        @RequestBody WorkProfileData empUpdate) {
	    employeeService.updateOwnProfile(empId, empUpdate);
	    Map<String, String> response = new HashMap<>();
        response.put("message", "Update applied successfully");
        return ResponseEntity.ok(response);
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> loginEmployee(
	        @RequestParam String email,
	        @RequestParam String password) {

	    WorkProfileData employee = employeeService.authenticate(email, password);
	    String token = jwtUtil.generateToken(employee);

	    return ResponseEntity.ok(Map.of(
	        "token", token,
	        "user", employee
	    ));
	}

    
    @GetMapping("/{empId}/payrolls")
    public ResponseEntity<List<CalculatedPayrollData>> getPayrolls(@PathVariable int empId) {
        List<CalculatedPayrollData> payrolls = employeeService.getpayrolls(empId);
        return ResponseEntity.ok(payrolls);
    }
    @PostMapping("/applyLeave")
    public ResponseEntity<Map<String, String>> applyLeave(@RequestBody LeaveRequestDto dto) {
        String message = employeeService.applyLeave(dto);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Leave applied successfully");
        
        return ResponseEntity.ok(response);
    }
    @GetMapping("/{empId}/leaves")
    public ResponseEntity<List<LeaveRequest>> showLeaveRecord(@PathVariable int empId) {
        List<LeaveRequest> leaveRecords = employeeService.showLeaveRecord(empId);
        return ResponseEntity.ok(leaveRecords);
    }
	
}
