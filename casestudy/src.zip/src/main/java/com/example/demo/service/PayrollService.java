package com.example.demo.service;

public interface PayrollService {

	

	String triggerPayrollForEmployee(int adminId, int empId);
}
