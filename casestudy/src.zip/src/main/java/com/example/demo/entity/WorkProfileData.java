package com.example.demo.entity;

import java.util.Date;

import com.example.demo.entity.enums.Gender;
import com.example.demo.entity.enums.roles;
import com.example.demo.entity.enums.status;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkProfileData {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int empId;
	private String FirstName;
	private String lastName;
	@Enumerated(EnumType.STRING)
	private Gender gender;
	private String email;
	private String password;
	private String department;
	private Date dateOfJoining;
	private String contactNumber;
	@Column(columnDefinition="TEXT")
	private String address;
	@Enumerated(EnumType.STRING)  
	private status status;
	@Enumerated(EnumType.STRING)
	roles role;

}
