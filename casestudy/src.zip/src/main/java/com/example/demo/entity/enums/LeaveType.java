package com.example.demo.entity.enums;

public enum LeaveType {
Sick,Casual,Maternity
}
