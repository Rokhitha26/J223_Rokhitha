package com.example.demo.dto;

import com.example.demo.entity.enums.roles;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminPayrollConfigDto {

	

    private Long id;
    @Enumerated(EnumType.STRING)
    private roles role;
    private double salary;
    private double hraPercent;
    private double pfPercent;
    private double bonusPercent;
    private double specialAllowancePercent;
    private double professionalTax;
}
