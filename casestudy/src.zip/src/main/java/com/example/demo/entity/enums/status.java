package com.example.demo.entity.enums;

public enum status {
active,inactive,terminated
}
