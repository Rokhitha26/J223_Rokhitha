package com.example.demo.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.AdminPayrollConfigDto;
import com.example.demo.dto.WorkProfileDataDto;
import com.example.demo.entity.AdminPayrollConfig;
import com.example.demo.entity.CalculatedPayrollData;
import com.example.demo.entity.WorkProfileData;
import com.example.demo.security.JwtUtil;
import com.example.demo.service.AdminService;
import com.example.demo.service.PayrollService;
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminServiceController {

    @Autowired
    private AdminService adminService;
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @Autowired
    private PayrollService payrollService;

    @PostMapping("/addEmployee")
    public ResponseEntity<Map<String, String>> addEmployee(@RequestBody WorkProfileData emp) {
        adminService.addEmployee(emp);
        return ResponseEntity.ok(Map.of("message", "Employee Added Successfully!"));

    }
    @GetMapping("/employee/{id}")
    public ResponseEntity<WorkProfileData> getEmployeeById(@PathVariable int id) {
        WorkProfileData employee = adminService.getEmployeeById(id);
        return ResponseEntity.ok(employee);
    }
    @PutMapping("/employee/updateEmployee")
    public ResponseEntity<Map<String, String>> updateEmployeeByAdmin(@RequestBody WorkProfileData updatedData) {
        adminService.updateEmployeeByAdmin(updatedData);
        return ResponseEntity.ok(Map.of("message", "Employee Added Successfully!"));
    }

    @DeleteMapping("/deleteEmployee/{empId}")
    public ResponseEntity<Map<String, String>> deleteEmployee(@PathVariable int empId) {
        adminService.deleteEmployee(empId);
        return ResponseEntity.ok(Map.of("message", "Employee deleted successfully."));

    }

    @GetMapping("/getAllEmployees")
    public ResponseEntity<List<WorkProfileDataDto>> getAllEmployees() {
        List<WorkProfileDataDto> employees = adminService.getAllEmployees();
        return ResponseEntity.ok(employees);
    }
    
    @PostMapping("/configurePayroll")
    public ResponseEntity<Map<String, String>> configurePayroll(@RequestBody AdminPayrollConfig dto) {
        String resultMessage = adminService.configPayrollData(dto);

        // If the result contains the word "Error", return a 400 Bad Request
        if (resultMessage.startsWith("Error")) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("message", resultMessage));
        }

        return ResponseEntity.ok(Map.of("message", resultMessage));
    }

    

    @GetMapping("/payrollConfig")
    public ResponseEntity<List<AdminPayrollConfig>> getCurrentPayrollConfiguredData() {
        List<AdminPayrollConfig> configs = adminService.getCurrentPayrollConfiguredData();
        return ResponseEntity.ok(configs);
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> loginAdmin(
            @RequestParam String email,
            @RequestParam String password) {

        WorkProfileData admin = adminService.authenticate(email, password);
        String token = jwtUtil.generateToken(admin);

        return ResponseEntity.ok(Map.of(
            "token", token,
            "user", admin
        ));
    }

   
    @GetMapping("/payrollTrigger/{date}")
    public ResponseEntity<List<CalculatedPayrollData>> triggerPayrollByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<CalculatedPayrollData> payrollList = adminService.payrollTrigger(date);
        return ResponseEntity.ok(payrollList);
    }
    @PostMapping("/triggerPayroll/{adminId}/{empId}")
    public ResponseEntity<String> triggerPayrollForEmployee(
        @PathVariable int adminId,
        @PathVariable int empId
    ) {
        String result = payrollService.triggerPayrollForEmployee(adminId, empId);
        return ResponseEntity.ok(result);
    }

}


