package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.LeaveRequestDto;
import com.example.demo.entity.CalculatedPayrollData;
import com.example.demo.entity.LeaveRequest;
import com.example.demo.entity.WorkProfileData;

public interface EmployeeService {


	List<CalculatedPayrollData> getpayrolls(int empId);
	String applyLeave(LeaveRequestDto dto);
	List<LeaveRequest>showLeaveRecord(int empId);
	WorkProfileData authenticate(String email, String password);
	void updateOwnProfile(int empId, WorkProfileData empUpdate);
	
}
