package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.LeaveRequest;
import com.example.demo.entity.WorkProfileData;

public interface ManagerService {
	void approveLeaveRequest(int requestId, String action);
	 List<LeaveRequest>showPendingLeaveRequest();
	 WorkProfileData authenticate(String email, String password);
}
