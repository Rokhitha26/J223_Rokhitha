package com.example.demo.service;

public interface EmailService {
	 void sendEmployeeWelcomeEmail(String to, int empId, String name);
}
