package com.example.demo.exception;

public class IllegalArgumentError extends RuntimeException {

	

	public IllegalArgumentError(String error) {
		super(error);
	}
}
