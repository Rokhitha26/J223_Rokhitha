package com.example.demo.dto;

import java.util.Date;

import com.example.demo.entity.enums.Gender;
import com.example.demo.entity.enums.roles;
import com.example.demo.entity.enums.status;
import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkProfileDataDto {
	
	//public WorkProfileDataDto(int empId2, String firstName2, String lastName2, Gender gender2, String email2,
		//	String department2, java.sql.Date dateOfJoining2, String contactNumber2, String address2,
			//status status2, roles role2) {
	//}
	
	int empId;
	private String firstName;
	private String lastName;
	@Enumerated(EnumType.STRING)
	private Gender gender;
	private String Email;
	private String department;
	private Date dateOfJoining;
	private String contactNumber;
	@Column(columnDefinition="TEXT")
	private String address;
	@Enumerated(EnumType.STRING)  
	private status status;
	@Enumerated(EnumType.STRING)
	roles role;
}
