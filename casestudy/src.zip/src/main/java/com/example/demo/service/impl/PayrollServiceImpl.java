package com.example.demo.service.impl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.AdminPayrollConfig;
import com.example.demo.entity.CalculatedPayrollData;
import com.example.demo.entity.PayrollAudits;
import com.example.demo.entity.WorkProfileData;
import com.example.demo.entity.enums.roles;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repo.AdminPayrollConfigRepo;
import com.example.demo.repo.CalculatedPayrollDataRepo;
import com.example.demo.repo.PayrollAuditsRepo;
import com.example.demo.repo.WorkProfileDataRepo;
import com.example.demo.service.PayrollService;

@Service
public class PayrollServiceImpl  implements PayrollService{

	@Autowired
	private PayrollAuditsRepo payrollRepo;
	
	@Autowired
	private WorkProfileDataRepo profileRepo;
	
	@Autowired
	private CalculatedPayrollDataRepo payrollDataRepo;
	
	@Autowired
	private AdminPayrollConfigRepo configRepo;
	
	@Override
	public String triggerPayrollForEmployee(int adminId, int empId) {
	    LocalDate date = LocalDate.now();
	    LocalTime time = LocalTime.now();

	    PayrollAudits audit = new PayrollAudits(0, adminId, date, time);
	    payrollRepo.save(audit);

	    WorkProfileData emp = profileRepo.findById(empId)
	        .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

	    roles empRole = emp.getRole();
	    AdminPayrollConfig config = configRepo.findByRoles(empRole)
	        .orElseThrow(() -> new ResourceNotFoundException("No such roles exist"));

	    double baseSalary = config.getSalary();
	    double hra = baseSalary * config.getHraPercent() / 100;
	    double pf = baseSalary * config.getPfPercent() / 100;
	    double bonus = baseSalary * config.getBonusPercent() / 100;
	    double specialAllowance = baseSalary * config.getSpecialAllowancePercent() / 100;
	    double professionalTax = config.getProfessionalTax();

	    double netSalary = baseSalary + hra + bonus + specialAllowance - pf - professionalTax;

	    CalculatedPayrollData finalSalary = new CalculatedPayrollData(
	        0,
	        emp.getEmpId(),
	        emp.getFirstName(),
	        emp.getLastName(),
	        emp.getDepartment(),
	        netSalary,
	        LocalDate.now()
	    );

	    payrollDataRepo.save(finalSalary);

	    return "Payroll generated successfully for Employee ID: " + empId;
	}

}
