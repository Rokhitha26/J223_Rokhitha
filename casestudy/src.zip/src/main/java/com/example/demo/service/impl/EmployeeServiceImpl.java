package com.example.demo.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.LeaveRequestDto;
import com.example.demo.entity.CalculatedPayrollData;
import com.example.demo.entity.LeaveRequest;
import com.example.demo.entity.WorkProfileData;
import com.example.demo.entity.enums.Gender;
import com.example.demo.entity.enums.LeaveStatus;
import com.example.demo.entity.enums.LeaveType;
import com.example.demo.entity.enums.roles;
import com.example.demo.exception.IllegalArgumentError;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repo.CalculatedPayrollDataRepo;
import com.example.demo.repo.LeaveRequestRepo;
import com.example.demo.repo.WorkProfileDataRepo;
import com.example.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private WorkProfileDataRepo profileRepo;
	
	
	@Autowired
	private CalculatedPayrollDataRepo payrollRepo;
	
	@Autowired
	private LeaveRequestRepo leaveRequestRepo;
	
	@Override
	public void updateOwnProfile(int empId, WorkProfileData empUpdate) {
	    WorkProfileData existing = profileRepo.findById(empId)
	        .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

	 

	    // Allow to change only contact and address
	    existing.setContactNumber(empUpdate.getContactNumber());
	    existing.setAddress(empUpdate.getAddress());

	    profileRepo.save(existing);
	}
	@Override
	public List<CalculatedPayrollData> getpayrolls(int empId) {
		
		if(!profileRepo.existsById(empId)) {
		 throw  new ResourceNotFoundException("Employee with "+empId+" is not found");
		}
		List<CalculatedPayrollData> payrolls = payrollRepo.findByEmpId(empId);
		return payrolls;
	}

	@Override
	public String applyLeave(LeaveRequestDto dto) {
		 WorkProfileData employee = profileRepo.findById(dto.getEmployeeId())
			        .orElseThrow(() -> new ResourceNotFoundException("Employee ID not found: " + dto.getEmployeeId()));
                
			 
			    LocalDate today = LocalDate.now();
			    LocalDate start = dto.getStartDate();
			    LocalDate end = dto.getEndDate();
                
			    if (start.isBefore(today)) {
			        throw new IllegalArgumentError("Start date cannot be in the past.");
			    }

			    if (end.isBefore(start)) {
			        throw new IllegalArgumentError("End date cannot be before start date.");
			    }
			    long totalDays = ChronoUnit.DAYS.between(start, end) + 1;
			    LeaveRequest leave = new LeaveRequest();
			    leave.setEmployeeId(dto.getEmployeeId());
			    leave.setEmployeeFirstName(employee.getFirstName());
			    leave.setEmployeeLastName(employee.getLastName());
			    leave.setStartDate(start);
			    leave.setEndDate(end);
			    leave.setDays((int) totalDays);
			    leave.setReason(dto.getReason());
			    leave.setLeaveType(dto.getLeaveType());
			    leave.setStatus(LeaveStatus.Pending);
			    leave.setAppliedAt(LocalDate.now());

			    leaveRequestRepo.save(leave);

			    return "Leave applied successfully!";
			}
	@Override
	public List<LeaveRequest> showLeaveRecord(int empId) {
		return leaveRequestRepo.findByEmployeeId(empId);
	}

	@Override
	public WorkProfileData authenticate(String email, String password) {
		 WorkProfileData employeeFound = profileRepo.findByEmailIgnoreCaseAndPassword(email, password);
		    
		    if (employeeFound != null) {
		        return employeeFound;
		    } else {
		        throw new ResourceNotFoundException("Invalid email or password");
		    }
	}


}
