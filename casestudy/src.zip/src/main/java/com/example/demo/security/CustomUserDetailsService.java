package com.example.demo.security;

import com.example.demo.entity.WorkProfileData;
import com.example.demo.entity.enums.roles;
import com.example.demo.repo.WorkProfileDataRepo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private WorkProfileDataRepo repo;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        WorkProfileData user = repo.findByEmailIgnoreCase(email);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }

        // Assuming you store role as a String like "Admin", "Manager", or "Employee"
        roles role = user.getRole();  // Get the role from the user entity
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_" + role));

        return new org.springframework.security.core.userdetails.User(
                user.getEmail(),
                user.getPassword(),
                authorities  // ✅ Pass the actual role authority here
        );
    }

}
