package com.example.demo.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.example.demo.entity.enums.LeaveStatus;
import com.example.demo.entity.enums.LeaveType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LeaveRequest {

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int requestId;
	    private int employeeId;
	    private String employeeFirstName;
	    private String employeeLastName;
	    private LocalDate startDate;
	    private LocalDate endDate;
	    private String reason;
	    private int days;

	    @Enumerated(EnumType.STRING)
	    private LeaveType leaveType;

	    @Enumerated(EnumType.STRING)
	    private LeaveStatus status;

	    private LocalDate appliedAt;
}
