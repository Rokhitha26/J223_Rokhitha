package com.example.demo.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.demo.service.EmailService;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Override
    public void sendEmployeeWelcomeEmail(String to, int empId, String name) {
    	try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject("Welcome to the Company!");
            message.setText("Hello " + name + ",\n\nWelcome to the Company!\nYour Employee ID is: " + empId + "\n\nRegards,\nHR Team");
            mailSender.send(message);
            System.out.println("Mail sent successfully to: " + to);
        } catch (Exception e) {
            System.err.println("Mail sending failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
