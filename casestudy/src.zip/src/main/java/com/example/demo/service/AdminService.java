package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;

import com.example.demo.dto.AdminPayrollConfigDto;
import com.example.demo.dto.WorkProfileDataDto;
import com.example.demo.entity.AdminPayrollConfig;
import com.example.demo.entity.CalculatedPayrollData;
import com.example.demo.entity.WorkProfileData;


public interface AdminService {

	
void addEmployee(WorkProfileData emp);

void deleteEmployee(int empId);
List<WorkProfileDataDto>getAllEmployees();
String configPayrollData(AdminPayrollConfig obj);
List<AdminPayrollConfig>getCurrentPayrollConfiguredData();
List<CalculatedPayrollData> payrollTrigger(LocalDate date);
WorkProfileData authenticate(String email, String password);
void updateByAdmin(int empId);
WorkProfileData getEmployeeById(int empId);
void updateEmployeeByAdmin(WorkProfileData updatedData);


}
