package com.example.demo.controller;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.example.demo.exception.ErrorCode;
import com.example.demo.exception.IllegalArgumentError;
import com.example.demo.exception.InternalServerErrorException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.exception.DuplicateEmailException;


@RestControllerAdvice
public class ControllerExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public ErrorCode resourceNotFound(ResourceNotFoundException ex, 
			WebRequest request
			) {
		ErrorCode message = new ErrorCode(HttpStatus.NOT_FOUND.value(), 
				
				new Date(), ex.getMessage(), request.getDescription(false));
		return message;
	}
	
	@ExceptionHandler(InternalServerErrorException.class)
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	public ErrorCode InternalServerError(InternalServerErrorException ex, 
			WebRequest request) {
		ErrorCode message=new ErrorCode(HttpStatus.NOT_FOUND.value(),
				new Date(), ex.getMessage(),request.getDescription(false));
		return message;
	}
	@ExceptionHandler(IllegalArgumentError.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public ErrorCode handleIllegalArgument(IllegalArgumentError ex, WebRequest request) {
	    return new ErrorCode(
	        HttpStatus.BAD_REQUEST.value(),
	        new Date(),
	        ex.getMessage(),
	        request.getDescription(false)
	    );
	}
	
	@ExceptionHandler(DuplicateEmailException.class)
	@ResponseStatus(value=HttpStatus.CONFLICT)
	public ErrorCode DuplicateEmailException(DuplicateEmailException ex, WebRequest request) {
		return new ErrorCode(
		HttpStatus.CONFLICT.value(), 
		new Date(),
		ex.getMessage(),
		request.getDescription(false)
		);
	}
    @ExceptionHandler(UserNotFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ErrorCode handleUserNotFoundException(UserNotFoundException ex, WebRequest request) {
        return new ErrorCode(
            HttpStatus.NOT_FOUND.value(),
            new Date(),
            ex.getMessage(),
            request.getDescription(false)
        );
    }
}