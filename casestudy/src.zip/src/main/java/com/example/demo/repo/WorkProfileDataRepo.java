package com.example.demo.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.WorkProfileData;

@Repository
public interface WorkProfileDataRepo extends JpaRepository<WorkProfileData,Integer>{

	boolean existsByEmail(String email);
	
	WorkProfileData findByEmailAndPassword(String email,String password);
	WorkProfileData findByEmailIgnoreCaseAndPassword(String email, String password);
	Optional<WorkProfileData> findByEmail(String email);

	WorkProfileData findByEmailIgnoreCase(String email);
}
