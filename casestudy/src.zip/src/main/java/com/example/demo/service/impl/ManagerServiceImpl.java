package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.LeaveRequest;
import com.example.demo.entity.WorkProfileData;
import com.example.demo.entity.enums.LeaveStatus;
import com.example.demo.exception.IllegalArgumentError;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repo.LeaveRequestRepo;
import com.example.demo.repo.WorkProfileDataRepo;
import com.example.demo.service.ManagerService;

@Service
public class ManagerServiceImpl implements ManagerService{

	
	@Autowired
	private LeaveRequestRepo leaveRequestRepo;
	
	@Autowired
	private WorkProfileDataRepo workProfileRepo;
	
	@Override
	public void approveLeaveRequest(int requestId, String action) {
	    LeaveRequest request = leaveRequestRepo.findByRequestIdAndStatus(requestId, LeaveStatus.Pending)
	        .orElseThrow(() -> new ResourceNotFoundException("Leave request not found or already processed."));

	    if (action.equalsIgnoreCase("ACCEPT")) {
	        request.setStatus(LeaveStatus.Approved);
	    } else if (action.equalsIgnoreCase("REJECT")) {
	        request.setStatus(LeaveStatus.Rejected);
	    } else {
	        throw new IllegalArgumentError("Action must be ACCEPT or REJECT.");
	    }

	    leaveRequestRepo.save(request);
	}


	@Override
	public List<LeaveRequest> showPendingLeaveRequest() {
	    return leaveRequestRepo.findByStatus(LeaveStatus.Pending);
	}


	@Override
	public WorkProfileData authenticate(String email, String password) {
		 WorkProfileData employeeFound = workProfileRepo.findByEmailIgnoreCaseAndPassword(email, password);
		    
		    if (employeeFound != null) {
		        return employeeFound;
		    } else {
		        throw new ResourceNotFoundException("Invalid email or password");
		    }
	}

}
