package com.example.demo.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.dto.AdminPayrollConfigDto;
import com.example.demo.dto.WorkProfileDataDto;
import com.example.demo.entity.AdminPayrollConfig;
import com.example.demo.entity.CalculatedPayrollData;
import com.example.demo.entity.WorkProfileData;
import com.example.demo.entity.enums.roles;
import com.example.demo.exception.DuplicateEmailException;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repo.AdminPayrollConfigRepo;
import com.example.demo.repo.CalculatedPayrollDataRepo;
import com.example.demo.repo.WorkProfileDataRepo;
import com.example.demo.service.AdminService;
import com.example.demo.service.EmailService;


@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private WorkProfileDataRepo profileRepo;
	
	@Autowired
	private EmailService emailService;
	
	
	@Autowired
	private AdminPayrollConfigRepo payrollConfigRepo;
	
	@Autowired
	private CalculatedPayrollDataRepo payrollRepo;
	

@Override
public void addEmployee(WorkProfileData emp) {
    if (profileRepo.existsByEmail(emp.getEmail())) {
        throw new DuplicateEmailException("Email already exists!");
    }
    WorkProfileData savedEmp = profileRepo.save(emp);

    // Call the email service
    emailService.sendEmployeeWelcomeEmail(
        savedEmp.getEmail(),
        savedEmp.getEmpId(),
        savedEmp.getFirstName()
    );
}
	@Override
	public void updateByAdmin(int empId) {
	    WorkProfileData existing = profileRepo.findById(empId)
	        .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

	

	    profileRepo.save(existing);
	}
	


	@Override
	public void deleteEmployee(int empId) {
	    WorkProfileData deleteEmp=profileRepo.findById(empId).orElseThrow(()->new ResourceNotFoundException("No such employeeId exists"));
	    profileRepo.delete(deleteEmp);
		
	}

	@Override
	public List<WorkProfileDataDto> getAllEmployees() {
		List<WorkProfileData> employees=profileRepo.findAll();		
		return employees.stream().map(emp->new WorkProfileDataDto(
				emp.getEmpId(),
				emp.getFirstName(),
				emp.getLastName(),
				emp.getGender(),
				emp.getEmail(),
				emp.getDepartment(),
				emp.getDateOfJoining(),
				emp.getContactNumber(),
				emp.getAddress(),
				emp.getStatus(),
				emp.getRole()	
				)).collect(Collectors.toList());
	}

	@Override
	public String configPayrollData(AdminPayrollConfig config) {
	    if (config.getRoles() == null) {
	        return "Error: Role is required for payroll configuration update.";
	    }

	    Optional<AdminPayrollConfig> existingConfig = payrollConfigRepo.findByRoles(config.getRoles());

	    if (existingConfig.isPresent()) {
	        AdminPayrollConfig savedConfig = existingConfig.get();
	        
	        savedConfig.setSalary(config.getSalary());
	        savedConfig.setHraPercent(config.getHraPercent());
	        savedConfig.setPfPercent(config.getPfPercent());
	        savedConfig.setBonusPercent(config.getBonusPercent());
	        savedConfig.setSpecialAllowancePercent(config.getSpecialAllowancePercent());
	        savedConfig.setProfessionalTax(config.getProfessionalTax());

	        payrollConfigRepo.save(savedConfig);

	        return "Payroll configuration updated successfully for role: " + config.getRoles();
	    } else {
	        return "Error: No existing configuration found for role: " + config.getRoles();
	    }
	}

	@Override
	public List<AdminPayrollConfig> getCurrentPayrollConfiguredData() {
	List<AdminPayrollConfig> currentPayrollConfiguredData=payrollConfigRepo.findAll();
		
		return currentPayrollConfiguredData;
	}

	@Override
	public List<CalculatedPayrollData> payrollTrigger(LocalDate date) {
	List<CalculatedPayrollData> payroll=payrollRepo.findByDate(date);
	return payroll;
	}



	@Override
	public WorkProfileData authenticate(String email, String password) {
	    WorkProfileData employeeFound = profileRepo.findByEmailIgnoreCaseAndPassword(email, password);
	    
	    if (employeeFound != null) {
	        return employeeFound;
	    } else {
	        throw new ResourceNotFoundException("Invalid email or password");
	    }
	}

	@Override
	public WorkProfileData getEmployeeById(int empId) {
		  return profileRepo.findById(empId)
	                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with ID: " + empId));
	}

	@Override
	@Transactional
	public void updateEmployeeByAdmin(WorkProfileData updatedData) {
	    int empId = updatedData.getEmpId();
	    WorkProfileData existing = profileRepo.findById(empId)
	            .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + empId));

	    // Update basic fields
	    existing.setFirstName(updatedData.getFirstName());
	    existing.setLastName(updatedData.getLastName());
	    existing.setEmail(updatedData.getEmail());
	    existing.setDepartment(updatedData.getDepartment());
	    existing.setContactNumber(updatedData.getContactNumber());
	    existing.setAddress(updatedData.getAddress());
	    
	    // Update enum fields with null checks
	    if (updatedData.getGender() != null) {
	        existing.setGender(updatedData.getGender());
	    }
	    
	    if (updatedData.getStatus() != null) {
	        existing.setStatus(updatedData.getStatus());
	    }
	    
	    if (updatedData.getRole() != null) {
	        existing.setRole(updatedData.getRole());
	    }
	    
	    // Update date field with null check
	    if (updatedData.getDateOfJoining() != null) {
	        existing.setDateOfJoining(updatedData.getDateOfJoining());
	    }
	    
	    // Password should only be updated if provided (security best practice)
	    if (updatedData.getPassword() != null && !updatedData.getPassword().isEmpty()) {
	        existing.setPassword(updatedData.getPassword());
	    }

	    // Save the updated entity
	    profileRepo.save(existing);
	}
	

}
