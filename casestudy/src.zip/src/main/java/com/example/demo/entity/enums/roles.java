package com.example.demo.entity.enums;

public enum roles {
Admin,Manager,Employee
}
