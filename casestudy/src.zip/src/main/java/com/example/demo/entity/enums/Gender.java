package com.example.demo.entity.enums;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Gender {
male,female,others;
}
