package com.example.demo.entity;

import com.example.demo.entity.enums.roles;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminPayrollConfig {

	
	@Id
    @GeneratedValue
    (strategy = GenerationType.IDENTITY)
    private Long id;
    @Enumerated(EnumType.STRING)
    private roles roles;
    private double salary;
    private double hraPercent;
    private double pfPercent;
    private double bonusPercent;
    private double specialAllowancePercent;
    private double professionalTax;
  
	
}
