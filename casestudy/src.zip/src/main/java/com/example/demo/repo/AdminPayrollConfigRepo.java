package com.example.demo.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.AdminPayrollConfig;
import com.example.demo.entity.enums.roles;

@Repository
public interface AdminPayrollConfigRepo extends JpaRepository<AdminPayrollConfig, Integer>{

	  Optional<AdminPayrollConfig> findByRoles(roles roles);
}
