package com.example.demo.entity.enums;

public enum LeaveStatus {
Pending,Approved,Rejected
}
