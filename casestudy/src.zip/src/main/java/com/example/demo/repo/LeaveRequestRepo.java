package com.example.demo.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.LeaveRequest;
import com.example.demo.entity.enums.LeaveStatus;

@Repository
public interface LeaveRequestRepo extends JpaRepository<LeaveRequest,Integer>{

	List<LeaveRequest> findByEmployeeId(int employeeId);
	  List<LeaveRequest> findByEmployeeIdAndStatus(int employeeId, LeaveStatus status);
	    List<LeaveRequest> findByStatus(LeaveStatus status);
	    Optional<LeaveRequest> findByRequestIdAndStatus(int requestId, LeaveStatus status);
}