package com.example.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.LeaveRequest;
import com.example.demo.entity.WorkProfileData;
import com.example.demo.security.JwtUtil;
import com.example.demo.service.ManagerService;

@RestController
@RequestMapping("/api/manager")
@CrossOrigin(origins = "http://localhost:4200")
public class ManagerServiceController {

    @Autowired
    private ManagerService managerService;
    
    @Autowired
    private JwtUtil jwtUtil;

 
    @PutMapping("/leaves/{requestId}")
    public ResponseEntity<String> approveOrRejectLeave(
            @PathVariable int requestId,
            @RequestParam String action) {
        managerService.approveLeaveRequest(requestId, action);
        return ResponseEntity.ok("Leave request " + action + "ED successfully");
    }


    @GetMapping("/leaves/pending")
    public ResponseEntity<List<LeaveRequest>> getPendingLeaves() {
        List<LeaveRequest> leaves = managerService.showPendingLeaveRequest();
        return ResponseEntity.ok(leaves);
    }


    @PostMapping("/login")
    public ResponseEntity<?> loginManager(
            @RequestParam String email,
            @RequestParam String password) {

        WorkProfileData manager = managerService.authenticate(email, password);
        String token = jwtUtil.generateToken(manager);

        return ResponseEntity.ok(Map.of(
            "token", token,
            "user", manager
        ));
    }

}
