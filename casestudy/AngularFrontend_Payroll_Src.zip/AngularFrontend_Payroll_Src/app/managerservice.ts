import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode'; // ✅ Correct import
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class Managerservice {
  private static readonly TOKEN_KEY = 'manager_token';
 private baseUrl = 'http://localhost:8080/api/manager';
  constructor(private http: HttpClient) {}

  getPendingLeaves(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/leaves/pending`);
  }
  static setToken(token: string): void {
    localStorage.setItem(this.TOKEN_KEY, token);
  }

  static getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  static clearToken(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem('manager_user');
  }

  static isLoggedIn(): boolean {
    return !!this.getToken();
  }

  static decodeToken(): any {
    const token = this.getToken();
    if (!token) return null;
    try {
      return jwtDecode(token); // ✅ works correctly now
    } catch (err) {
      console.error('Token decode failed', err);
      return null;
    }
  }
}
