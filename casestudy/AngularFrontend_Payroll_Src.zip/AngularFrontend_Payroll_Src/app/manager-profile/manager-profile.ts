import { Component } from '@angular/core';

@Component({
  selector: 'app-manager-profile',
  imports: [],
  templateUrl: './manager-profile.html',
  styleUrl: './manager-profile.css'
})
export class ManagerProfile {

}
