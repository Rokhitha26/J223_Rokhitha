import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Adminservice } from './adminservice';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const adminService = inject(Adminservice);
  const token = adminService.getToken();

  if (token) {
    const cloned = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    return next(cloned);
  }

  return next(req);
};
