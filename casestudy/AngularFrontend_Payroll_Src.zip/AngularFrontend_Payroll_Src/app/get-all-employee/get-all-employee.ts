import { Component, OnInit } from '@angular/core';
import { Adminservice } from '../adminservice';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';

@Component({
  selector: 'app-get-all-employee',
  templateUrl: './get-all-employee.html',
  styleUrls: ['./get-all-employee.css'],
  
  imports:[MatFormFieldModule,MatInputModule,MatTableModule,MatPaginatorModule,MatSortModule,ReactiveFormsModule]
})
export class GetAllEmployee implements OnInit {
  employees: any[] = [];
  filteredEmployees: any[] = [];
  searchControl = new FormControl('');

  constructor(private adminService: Adminservice) {}

  ngOnInit(): void {
    this.adminService.getAllEmployees().subscribe(data => {
      this.employees = data;
      this.filteredEmployees = data;
    });

    this.searchControl.valueChanges.subscribe(value => {
      this.filterByEmpId(value);
    });
  }

  filterByEmpId(empId: string) {
    if (!empId) {
      this.filteredEmployees = this.employees;
      return;
    }

    const id = parseInt(empId, 10);
    const match = this.employees.filter(emp => emp.empId === id);
    const others = this.employees.filter(emp => emp.empId !== id);
    this.filteredEmployees = [...match, ...others];
  }
}
