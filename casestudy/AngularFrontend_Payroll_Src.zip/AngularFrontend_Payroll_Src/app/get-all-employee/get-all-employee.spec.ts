import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAllEmployee } from './get-all-employee';

describe('GetAllEmployee', () => {
  let component: GetAllEmployee;
  let fixture: ComponentFixture<GetAllEmployee>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GetAllEmployee]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetAllEmployee);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
