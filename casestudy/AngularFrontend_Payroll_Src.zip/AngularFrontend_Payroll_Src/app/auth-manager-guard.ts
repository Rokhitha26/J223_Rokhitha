// auth-manager.guard.ts
import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { Managerservice } from './managerservice';

export const authManagerGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  if (Managerservice.isLoggedIn()) {
    return true;
  } else {
    router.navigate(['/manager/login']);  // Adjust path as needed
    return false;
  }
};
