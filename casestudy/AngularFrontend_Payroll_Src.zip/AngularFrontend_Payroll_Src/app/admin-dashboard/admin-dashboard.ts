import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { Adminservice } from '../adminservice';
import { Router } from '@angular/router';
import { MatIconModule } from "@angular/material/icon";
@Component({
  selector: 'app-admin-dashboard',
    standalone: true,
  imports: [CommonModule, RouterModule, RouterOutlet, MatIconModule],
  templateUrl: './admin-dashboard.html',
  styleUrl: './admin-dashboard.css'
})
export class AdminDashboard {
 constructor(private adminService: Adminservice, private router: Router) {}

  logout(): void {
    this.adminService.logout();
  }
}
