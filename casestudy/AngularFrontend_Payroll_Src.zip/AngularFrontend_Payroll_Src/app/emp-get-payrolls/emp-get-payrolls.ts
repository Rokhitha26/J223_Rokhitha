import { Component, OnInit } from '@angular/core';
import { Employeeservice } from '../employeeservice';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-emp-get-payroll',
  templateUrl: './emp-get-payrolls.html',
  styleUrls: ['./emp-get-payrolls.css'],
  imports:[CommonModule,FormsModule,RouterModule,MatTableModule,MatCardModule,MatProgressSpinnerModule]
})
export class EmpGetPayrolls implements OnInit {
  displayedColumns: string[] = [
  'id',
  'date',
  'empId',
  'empFirstName',
  'empLastName',
  'empDepartment',
  'empsalary'
];

  payrolls: any[] = [];
  errorMessage: string = '';

  
  errorMsg: string;

  constructor(private EmployeeService: Employeeservice) {}
ngOnInit(): void {
  const userDataString = localStorage.getItem('employee_user');
  if (userDataString) {
    const userData = JSON.parse(userDataString);
    const empId = userData.empId;

    this.EmployeeService.getPayrolls(empId).subscribe({
      next: (data) => {
        this.payrolls = data;
      },
      error: (err) => {
        console.error('Error fetching payrolls:', err);
      }
    });
  } else {
    this.errorMsg = "Employee ID not found in localStorage.";
  }
}
}