import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpGetPayrolls } from './emp-get-payrolls';

describe('EmpGetPayrolls', () => {
  let component: EmpGetPayrolls;
  let fixture: ComponentFixture<EmpGetPayrolls>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmpGetPayrolls]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpGetPayrolls);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
