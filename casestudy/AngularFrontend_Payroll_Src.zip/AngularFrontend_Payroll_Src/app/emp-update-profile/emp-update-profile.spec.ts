import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpUpdateProfile } from './emp-update-profile';

describe('EmpUpdateProfile', () => {
  let component: EmpUpdateProfile;
  let fixture: ComponentFixture<EmpUpdateProfile>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmpUpdateProfile]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpUpdateProfile);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
