import { Component, OnInit } from '@angular/core';
import { Employeeservice } from '../employeeservice';
import { HttpErrorResponse } from '@angular/common/http';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-emp-update-profile',
  templateUrl: './emp-update-profile.html',
  styleUrls: ['./emp-update-profile.css'],
  standalone: true,
  imports: [MatInputModule, CommonModule, FormsModule, RouterModule]
})
export class EmpUpdateProfile implements OnInit {
  employee: any = {};  // Will hold all employee details
  contactNumber: string = '';
  address: string = '';
  password: string = '';
  message: string = '';

  constructor(private Employeeservice: Employeeservice) {}

  ngOnInit(): void {
    const stored = localStorage.getItem('employee_user');
    if (stored) {
      const emp = JSON.parse(stored);
      this.employee = emp;
      this.contactNumber = emp.contactNumber;
      this.address = emp.address;
    } else {
      this.message = 'Employee data not found in localStorage.';
      console.error(this.message);
    }
  }

  onUpdate(): void {
    const stored = localStorage.getItem('employee_user');
    if (!stored) {
      this.message = 'Employee data not found in localStorage.';
      return;
    }

    const emp = JSON.parse(stored);
    const empId = emp.empId;

    const updateData = {
      contactNumber: this.contactNumber,
      address: this.address,
      password: this.password
    };

    this.Employeeservice.updateOwnProfile(empId, updateData)
      .subscribe({
        next: () => this.message = 'Profile updated successfully.',
        error: (err: HttpErrorResponse) => {
          console.error('Update error:', err);
          this.message = err.error.message || 'Update failed.';
        }
      });
  }
}
