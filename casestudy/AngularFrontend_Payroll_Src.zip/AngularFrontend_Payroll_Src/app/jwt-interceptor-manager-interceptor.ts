// jwt-interceptor-manager.ts
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Managerservice } from './managerservice';

export const jwtInterceptorManagerInterceptor: HttpInterceptorFn = (req, next) => {
  const token = Managerservice.getToken();

  if (token) {
    const cloned = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    return next(cloned);
  }

  return next(req);
};
