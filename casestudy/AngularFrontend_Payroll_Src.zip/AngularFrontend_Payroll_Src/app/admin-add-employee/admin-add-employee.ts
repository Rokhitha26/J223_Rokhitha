// admin-add-employee.component.ts
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Adminservice } from '../adminservice';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-add-employee',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-add-employee.html',
  styleUrls: ['./admin-add-employee.css']
})
export class AdminAddEmployee {
  employee = {
    firstName: '',
    lastName: '',
    gender: '',
    email: '',
    password: '',
    department: '',
    dateOfJoining: '',
    contactNumber: '',
    address: '',
    status: 'active',
    role: 'Employee' // Default role
  };

  successMessage: string = '';
  errorMessage: string = '';

  constructor(
    private adminService: Adminservice,
    private router: Router
  ) {}

  onSubmit(): void {
  this.successMessage = '';
  this.errorMessage = '';

  // Convert date to proper format if needed
  const formattedEmployee = {
    ...this.employee,
    dateOfJoining: new Date(this.employee.dateOfJoining).toISOString()
  };

  this.adminService.addEmployee(formattedEmployee).subscribe({
    next: (response) => {
      this.successMessage = 'Employee added successfully!';
      this.resetForm();
    },
    error: (error) => {
      console.error('Full error:', error);
      if (error.status === 0) {
        this.errorMessage = 'Unable to connect to server. Please check your connection.';
      } else if (error.error && error.error.message) {
        this.errorMessage = error.error.message;
      } else {
        this.errorMessage = 'Failed to add employee. Please try again.';
      }
    }
  });
}

private resetForm(): void {
  this.employee = {
    firstName: '',
    lastName: '',
    gender: '',
    email: '',
    password: '',
    department: '',
    dateOfJoining: '',
    contactNumber: '',
    address: '',
    status: 'active',
    role: 'Employee'
  };}}