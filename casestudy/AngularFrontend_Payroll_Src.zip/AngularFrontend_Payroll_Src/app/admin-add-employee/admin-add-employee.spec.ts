import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddEmployee } from './admin-add-employee';

describe('AdminAddEmployee', () => {
  let component: AdminAddEmployee;
  let fixture: ComponentFixture<AdminAddEmployee>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminAddEmployee]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminAddEmployee);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
