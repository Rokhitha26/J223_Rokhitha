import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-manager-dashboard',
  imports: [CommonModule,FormsModule,RouterModule],
  templateUrl: './manager-dashboard.html',
  styleUrl: './manager-dashboard.css'
})
export class ManagerDashboard {
quickApprove() {
throw new Error('Method not implemented.');
}
viewNotifications() {
throw new Error('Method not implemented.');
}
isSidebarVisible: any;
activeTab: any;
unreadCount: any;
subscriberCount: any;
learnMore: any;

  constructor(private router: Router) {}
toggleSidebar() {
  this.isSidebarVisible = !this.isSidebarVisible;
}
  logout() {
    localStorage.clear(); // or remove specific keys like localStorage.removeItem('jwt')
    this.router.navigate(['']); // navigate to empty route (landing page)
  }
 


}
