import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Adminservice } from '../adminservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-update-employee',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-update-employee.html',
  styleUrls: ['./admin-update-employee.css']
})
export class AdminUpdateEmployee {

  employeeId: number | null = null;
  isLoading: boolean = false;
  isFormEnabled: boolean = false;

  employeeData = {
    empId: 0,
    firstName: '',
    lastName: '',
    gender: '',
    email: '',
    password: '',
    department: '',
    dateOfJoining: '',
    contactNumber: '',
    address: '',
    status: 'active',
    role: 'Employee'
  };

  successMessage: string = '';
  errorMessage: string = '';

  constructor(
    private adminService: Adminservice,
    private router: Router
  ) {}

  loadEmployee(): void {
    if (!this.employeeId) {
      this.errorMessage = 'Please enter a valid employee ID';
      this.isFormEnabled = false;
      return;
    }

    this.isLoading = true;
    this.successMessage = '';
    this.errorMessage = '';

    this.adminService.getEmployeeById(this.employeeId).subscribe({
      next: (employee) => {
        this.employeeData = {
          ...employee,
          empId: employee.empId,
          dateOfJoining: employee.dateOfJoining.split('T')[0]
        };
        this.successMessage = 'Employee loaded successfully';
        this.isLoading = false;
        this.isFormEnabled = true;
      },
      error: (error) => {
        console.error('Error loading employee:', error);
        this.errorMessage = error.status === 404
          ? `Employee with ID ${this.employeeId} not found`
          : 'Failed to load employee data';

        this.resetEmployeeForm();
        this.isLoading = false;
        this.isFormEnabled = false;
      }
    });
  }

  onSubmit(): void {
    this.successMessage = '';
    this.errorMessage = '';
    this.isLoading = true;

    this.adminService.updateEmployee(this.employeeData).subscribe({
      next: () => {
        this.successMessage = `Employee ${this.employeeData.firstName} updated successfully!`;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error updating employee:', error);
        this.errorMessage = this.getErrorMessage(error);
        this.isLoading = false;
      }
    });
  }

  private resetEmployeeForm(): void {
    this.employeeData = {
      empId: 0,
      firstName: '',
      lastName: '',
      gender: '',
      email: '',
      password: '',
      department: '',
      dateOfJoining: '',
      contactNumber: '',
      address: '',
      status: 'active',
      role: 'Employee'
    };
  }

  private getErrorMessage(error: any): string {
    if (error.status === 403) {
      return 'Access denied. You may not have permission to update employees.';
    } else if (error.status === 401) {
      return 'Session expired. Please log in again.';
    } else if (error.error?.message) {
      return error.error.message;
    }
    return 'Failed to update employee. Please try again.';
  }

  logout(): void {
    this.adminService.logout();
  }
}
