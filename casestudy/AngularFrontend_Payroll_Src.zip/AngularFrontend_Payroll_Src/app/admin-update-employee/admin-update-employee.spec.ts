import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUpdateEmployee } from './admin-update-employee';

describe('AdminUpdateEmployee', () => {
  let component: AdminUpdateEmployee;
  let fixture: ComponentFixture<AdminUpdateEmployee>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminUpdateEmployee]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminUpdateEmployee);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
