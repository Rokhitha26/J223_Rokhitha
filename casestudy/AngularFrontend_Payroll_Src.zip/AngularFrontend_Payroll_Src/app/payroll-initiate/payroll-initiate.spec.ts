import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayrollInitiate } from './payroll-initiate';

describe('PayrollInitiate', () => {
  let component: PayrollInitiate;
  let fixture: ComponentFixture<PayrollInitiate>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PayrollInitiate]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PayrollInitiate);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
