import { Component, OnInit } from '@angular/core';
import { Adminservice } from '../adminservice';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-payroll-initiate',
  templateUrl: './payroll-initiate.html',
  styleUrls: ['./payroll-initiate.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule]
})
export class PayrollInitiate implements OnInit {
  adminId: number = 1;
  message: string = '';
  isLoading: boolean = false;
  error: string = '';
  employees: any[] = [];

  // ✅ Track sanctioned employee IDs
  sanctionedEmpIds: number[] = [];

  constructor(private Adminservice: Adminservice) {}

  ngOnInit() {
    this.Adminservice.getAllEmployees().subscribe({
      next: (res) => this.employees = res,
      error: () => this.error = 'Failed to load employees'
    });
  }

  triggerPayrollFor(empId: number) {
    this.Adminservice.triggerPayrollForEmployee(this.adminId, empId).subscribe({
      next: (res) => {
        this.sanctionedEmpIds.push(empId); // ✅ mark as sanctioned
        alert(res);
      },
      error: (err) => alert("Error: " + err.error)
    });
  }

  // ✅ Utility method for template
  isSanctioned(empId: number): boolean {
    return this.sanctionedEmpIds.includes(empId);
  }
}
