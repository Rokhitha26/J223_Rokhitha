export interface CalculatedPayrollData {
  employeeId: string;
  employeeName: string;
  basicSalary: number;
  hra: number;
  pf: number;
  bonus: number;
  specialAllowance: number;
  professionalTax: number;
  netSalary: number;
}