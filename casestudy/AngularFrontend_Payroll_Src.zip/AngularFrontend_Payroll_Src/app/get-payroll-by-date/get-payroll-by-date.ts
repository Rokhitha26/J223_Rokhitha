import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Adminservice } from '../adminservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-payroll-by-date',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './get-payroll-by-date.html',
  styleUrls: ['./get-payroll-by-date.css']
})
export class AdminPayrollByDate {
  selectedDate: string = '';
  payrollData: any[] = [];
  isLoading: boolean = false;
  errorMessage: string = '';
  noDataFound: boolean = false;

  constructor(
    private adminService: Adminservice,
    private router: Router
  ) {}

  getCurrentDate(): string {
    return new Date().toISOString().split('T')[0];
  }

  fetchPayrollData(): void {
    if (!this.selectedDate) {
      this.errorMessage = 'Please select a date';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    this.noDataFound = false;
    this.payrollData = [];

    this.adminService.getPayrollByDate(this.selectedDate).subscribe({
      next: (data) => {
        this.payrollData = data;
        this.noDataFound = data.length === 0;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error:', error);
        this.errorMessage = 'Failed to fetch payroll data';
        this.isLoading = false;
      }
    });
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  logout(): void {
    this.adminService.logout();
  }
}