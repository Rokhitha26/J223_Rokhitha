import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetPayrollByDate } from './get-payroll-by-date';

describe('GetPayrollByDate', () => {
  let component: GetPayrollByDate;
  let fixture: ComponentFixture<GetPayrollByDate>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GetPayrollByDate]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetPayrollByDate);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
