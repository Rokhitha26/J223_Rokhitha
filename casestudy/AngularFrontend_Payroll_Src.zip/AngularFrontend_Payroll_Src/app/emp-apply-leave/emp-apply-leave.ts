import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Employeeservice } from '../employeeservice';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-apply-leave',
  templateUrl: './emp-apply-leave.html',
  styleUrls: ['./emp-apply-leave.css'],
  imports:[FormsModule,CommonModule,RouterModule,ReactiveFormsModule]
})
export class EmpApplyLeave implements OnInit {
  leaveForm: FormGroup;
  gender: string = '';
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private employeeService: Employeeservice,
    private router: Router
  ) {
    this.leaveForm = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      leaveType: ['', Validators.required],
      reason: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.gender = localStorage.getItem('empGender') || '';
  }

  onSubmit(): void {
    if (this.leaveForm.invalid) return;

    const empId = localStorage.getItem('empId');
    if (!empId) {
      this.errorMessage = 'Employee ID not found. Please log in again.';
      return;
    }

    const formData = {
      ...this.leaveForm.value,
      employeeId: parseInt(empId)
    };

    this.employeeService.applyLeave(formData).subscribe({
      next: (res) => {
        this.successMessage = res;
        this.leaveForm.reset();
      },
      error: (err) => {
        this.errorMessage = 'Failed to apply for leave.';
        console.error(err);
      }
    });
  }
}
