import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpApplyLeave } from './emp-apply-leave';

describe('EmpApplyLeave', () => {
  let component: EmpApplyLeave;
  let fixture: ComponentFixture<EmpApplyLeave>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmpApplyLeave]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpApplyLeave);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
