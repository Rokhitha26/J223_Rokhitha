import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-mgr-show-pending',
   standalone: true,
  templateUrl: './mgr-show-pending.html',
  styleUrls: ['./mgr-show-pending.css'],
  imports:[CommonModule,FormsModule,RouterModule]

})
export class MgrShowPending implements OnInit {
  leaves: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchPendingLeaves();
  }

  fetchPendingLeaves(): void {
    this.http.get<any[]>('http://localhost:8080/api/manager/leaves/pending')
      .subscribe({
        next: (data) => {
          this.leaves = data;
        },
        error: (error) => {
          console.error('Error fetching pending leaves:', error);
        }
      });
  }
}
