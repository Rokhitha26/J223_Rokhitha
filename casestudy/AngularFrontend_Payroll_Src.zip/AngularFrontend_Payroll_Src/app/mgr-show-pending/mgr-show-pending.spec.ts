import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MgrShowPending } from './mgr-show-pending';

describe('MgrShowPending', () => {
  let component: MgrShowPending;
  let fixture: ComponentFixture<MgrShowPending>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MgrShowPending]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MgrShowPending);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
