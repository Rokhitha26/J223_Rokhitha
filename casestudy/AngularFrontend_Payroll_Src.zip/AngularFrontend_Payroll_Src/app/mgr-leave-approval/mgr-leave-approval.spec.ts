import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MgrLeaveApproval } from './mgr-leave-approval';

describe('MgrLeaveApproval', () => {
  let component: MgrLeaveApproval;
  let fixture: ComponentFixture<MgrLeaveApproval>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MgrLeaveApproval]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MgrLeaveApproval);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
