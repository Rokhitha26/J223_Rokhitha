import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-mgr-leave-approval',
  templateUrl: './mgr-leave-approval.html',
  styleUrls: ['./mgr-leave-approval.css'],
  imports:[CommonModule,FormsModule,RouterModule]
})
export class MgrLeaveApproval implements OnInit {
  pendingLeaves: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchPendingLeaves();
  }

  fetchPendingLeaves(): void {
    this.http.get<any[]>('http://localhost:8080/api/manager/leaves/pending')
      .subscribe({
        next: (data) => this.pendingLeaves = data,
        error: (err) => console.error('Error fetching pending leaves:', err)
      });
  }

  takeAction(requestId: number, action: string): void {
    const url = `http://localhost:8080/api/manager/leaves/${requestId}?action=${action}`;
    this.http.put(url, null, { responseType: 'text' })
      .subscribe({
        next: (response) => {
          alert(response);
          this.pendingLeaves = this.pendingLeaves.filter(leave => leave.requestId !== requestId);
        },
        error: (err) => {
          alert('Error processing leave: ' + err.error);
          console.error(err);
        }
      });
  }
}
