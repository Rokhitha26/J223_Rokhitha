import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap } from 'rxjs';
import { Router } from '@angular/router';
import { CalculatedPayrollData } from './models/calculated-payroll-data';

@Injectable({
  providedIn: 'root'
})
export class Adminservice {
  private apiUrl = 'http://localhost:8080/api/admin';

  constructor(private _http: HttpClient, private router: Router) { }
  private getHeaders(): HttpHeaders {
    const token = this.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }
  loginAdmin(email: string, password: string): Observable<any> {
    return this._http.post(`${this.apiUrl}/login`, null, {
      params: { email, password }
    }).pipe(
      tap((response: any) => {
        // Create a copy of the user object without the password
        const userWithoutPassword = this.excludePassword(response.user);
        
        // Store token and user data in localStorage
        localStorage.setItem('admin_token', response.token);
        localStorage.setItem('admin_user', JSON.stringify(userWithoutPassword));
      })
    );
  }
addEmployee(employeeData: any): Observable<any> {
    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.getToken()}`
    });
    
    return this._http.post(`${this.apiUrl}/addEmployee`, employeeData, { headers })
        .pipe(
            catchError(error => {
                console.error('Error adding employee:', error);
                throw error;
            })
        );
}
configurePayroll(payrollData: any): Observable<any> {
    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.getToken()}`
    });
    
    return this._http.post(`${this.apiUrl}/configurePayroll`, payrollData, { headers })
        .pipe(
            catchError(error => {
                console.error('Error configuring payroll:', error);
                throw error;
            })
        );
}
// Add this to your Adminservice class
deleteEmployee(empId: number): Observable<any> {
    const headers = new HttpHeaders({
        'Authorization': `Bearer ${this.getToken()}`
    });
    
    return this._http.delete(`${this.apiUrl}/deleteEmployee/${empId}`, { headers })
        .pipe(
            catchError(error => {
                console.error('Error deleting employee:', error);
                throw error;
            })
        );
}
getPayrollConfig(): Observable<any> {
    const headers = new HttpHeaders({
        'Authorization': `Bearer ${this.getToken()}`
    });
    
    return this._http.get(`${this.apiUrl}/payrollConfig`, { headers });
}
  // Helper method to exclude password from user object
  private excludePassword(user: any): any {
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('admin_token');
  }

  logout(): void {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_user');
    this.router.navigate(['']);
  }
updateEmployee(employeeData: any): Observable<any> {
    const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.getToken()}`
    });
    
    console.log('Sending headers:', headers); // Debug log
    
    return this._http.put(`${this.apiUrl}/employee/updateEmployee`, employeeData, { headers })
        .pipe(
            catchError(error => {
                console.error('Full error details:', error); // More detailed error logging
                throw error;
            })
        );
}
// Add this to your Adminservice
getPayrollByDate(date: string): Observable<CalculatedPayrollData[]> {
    const headers = new HttpHeaders({
        'Authorization': `Bearer ${this.getToken()}`
    });
    
    // Note: Using path variable format to match your backend
    return this._http.get<CalculatedPayrollData[]>(`${this.apiUrl}/payrollTrigger/${date}`, { headers })
        .pipe(
            catchError(error => {
                console.error('Error fetching payroll:', error);
                throw error;
            })
        );
}
getAllEmployees(): Observable<any[]> {
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${this.getToken()}`
  });

  return this._http.get<any[]>(`${this.apiUrl}/getAllEmployees`, { headers });
}

triggerPayrollForEmployee(adminId: number, empId: number) {
  const token = this.getToken(); // Uses the helper method and correct key
  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  });

  return this._http.post(`${this.apiUrl}/triggerPayroll/${adminId}/${empId}`, {}, { headers, responseType: 'text' });
}


getEmployeeById(empId: number): Observable<any> {
    const headers = new HttpHeaders({
        'Authorization': `Bearer ${this.getToken()}`
    });
    
    return this._http.get(`${this.apiUrl}/employee/${empId}`, { headers });
}
  getToken(): string | null {
    return localStorage.getItem('admin_token');
  }

  // Add a method to get the user data
  getUser(): any {
    const user = localStorage.getItem('admin_user');
    return user ? JSON.parse(user) : null;
  }
}