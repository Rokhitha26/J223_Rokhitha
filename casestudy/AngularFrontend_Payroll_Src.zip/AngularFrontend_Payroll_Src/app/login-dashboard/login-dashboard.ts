import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { Adminservice } from '../adminservice';
import { AfterViewInit } from '@angular/core';
@Component({
  selector: 'app-login-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule
  ],
  templateUrl: './login-dashboard.html',
  styleUrls: ['./login-dashboard.css']
})
export class LoginDashboard implements AfterViewInit  {
  adminForm: FormGroup;
  adminErrorMessage: string = '';
ngAfterViewInit(): void {
    const video = document.querySelector('.background-video') as HTMLVideoElement;
    if (video) {
      video.play().catch(err => {
        console.warn('Autoplay failed:', err);
      });
    }
  }
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private adminService: Adminservice
  ) {
    this.adminForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  adminLogin(): void {
    const { email, password } = this.adminForm.value;
    this.adminErrorMessage = '';

    this.adminService.loginAdmin(email, password).subscribe({
      next: (response) => {
        // Navigate on success
        this.router.navigate(['/admin/dashboard']);
      },
      error: (err) => {
        this.adminErrorMessage = 'Invalid credentials. Please try again.';
        console.error('Admin login failed:', err);
      }
    });
  }
}
