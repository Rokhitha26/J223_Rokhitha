import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { Employeeservice } from '../employeeservice';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatIconModule } from "@angular/material/icon";

@Component({
  selector: 'app-employee-login',
  templateUrl: './employee-login.html',
  imports: [CommonModule, FormsModule, RouterModule, ReactiveFormsModule, MatIconModule],
  styleUrls: ['./employee-login.css']
})
export class EmployeeLogin {
  loginForm: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private employeeService: Employeeservice,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }
onSubmit(): void {
  if (this.loginForm.invalid) return;

  const { email, password } = this.loginForm.value;

  this.employeeService.login(email, password).subscribe({
    next: (res) => {
      const { token, user } = res;

      // ✅ Store token using service method
      Employeeservice.setToken(token);

      // ✅ Store other data
      localStorage.setItem('empId', user.empId);
      localStorage.setItem('empGender', user.gender);
      localStorage.setItem('employee_user', JSON.stringify(user));

      // ✅ Navigate
      this.router.navigate(['/employee/dashboard']);
    },
    error: (err) => {
      this.errorMessage = 'Invalid credentials. Please try again.';
      console.error('Login error:', err);
    }
  });
}


}
