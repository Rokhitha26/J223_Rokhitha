import { TestBed } from '@angular/core/testing';

import { Managerservice } from './managerservice';

describe('Managerservice', () => {
  let service: Managerservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Managerservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
