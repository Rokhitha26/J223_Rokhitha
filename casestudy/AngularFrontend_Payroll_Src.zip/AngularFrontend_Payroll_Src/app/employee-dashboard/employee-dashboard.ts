import { CommonModule } from '@angular/common';
import { AfterViewInit, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Employeeservice } from '../employeeservice';
@Component({
  selector: 'app-employee-dashboard',
  imports: [CommonModule,FormsModule,RouterModule],
  templateUrl: './employee-dashboard.html',
  styleUrl: './employee-dashboard.css'
})
export class EmployeeDashboard implements AfterViewInit  {
constructor(private employeeService: Employeeservice, private router: Router) {}
ngAfterViewInit(): void {
    const video = document.querySelector('.background-video') as HTMLVideoElement;
    if (video) {
      video.play().catch(err => {
        console.warn('Autoplay failed:', err);
      });
    }
  }isSidebarVisible = false;

toggleSidebar() {
  this.isSidebarVisible = !this.isSidebarVisible;
}

  logout(): void {
    this.employeeService.logoutAndRedirect(this.router);
  }
}
