import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Adminservice } from './adminservice'; 

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private adminService: Adminservice,
    private router: Router
  ) {}

  canActivate(): boolean {
    if (this.adminService.isLoggedIn()) {
      return true;
    } else {
      this.router.navigate(['/admin/login']);
      return false;
    }
  }
}