// manager-login.component.ts
import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Managerservice } from '../managerservice';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from "@angular/material/icon";
import { AfterViewInit} from '@angular/core';

@Component({
  selector: 'app-manager-login',
  templateUrl: './manager-login.html',
   styleUrls: ['./manager-login.css'],
  imports: [CommonModule, FormsModule, RouterModule, MatIconModule]
})
export class ManagerLogin implements AfterViewInit{
  email = '';
  password = '';
  error = '';
 ngAfterViewInit(): void {
    const video = document.querySelector('.background-video') as HTMLVideoElement;
    if (video) {
      video.play().catch(err => {
        console.warn('Video autoplay failed:', err);
      });
    }
  }
  constructor(private http: HttpClient, private router: Router) {}

  loginManager() {
    const params = new HttpParams()
      .set('email', this.email)
      .set('password', this.password);

    this.http.post<any>('http://localhost:8080/api/manager/login', null, { params }).subscribe({
      next: (res) => {
        Managerservice.setToken(res.token);
        localStorage.setItem('manager_user', JSON.stringify(res.user));
        this.router.navigate(['/manager/dashboard']);
      },
      error: (err) => {
        console.error(err);
        this.error = 'Invalid email or password';
      }
    });
  }
}
