import { AfterViewInit, Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Adminservice } from '../adminservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-config-payroll',
  standalone: true,
  imports: [CommonModule, FormsModule,    ReactiveFormsModule],
  templateUrl: './admin-config-payroll.html',
  styleUrls: ['./admin-config-payroll.css']
})
export class AdminConfigPayroll implements AfterViewInit  {
  payrollConfig = {
    roles: '',
    salary: 0,
    hraPercent: 0,
    pfPercent: 0,
    bonusPercent: 0,
    specialAllowancePercent: 0,
    professionalTax: 0
  };

  successMessage: string = '';
  errorMessage: string = '';
  existingConfigs: any[] = [];
ngAfterViewInit(): void {
    const video = document.querySelector('.background-video') as HTMLVideoElement;
    if (video) {
      video.play().catch(err => {
        console.warn('Autoplay failed:', err);
      });
    }
  }
  constructor(
    private adminService: Adminservice,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadExistingConfigs();
  }

  loadExistingConfigs(): void {
    this.adminService.getPayrollConfig().subscribe({
      next: (configs) => {
        this.existingConfigs = configs;
      },
      error: (error) => {
        console.error('Error loading payroll configs:', error);
        this.errorMessage = 'Failed to load existing configurations';
      }
    });
  }

  onSubmit(): void {
    this.successMessage = '';
    this.errorMessage = '';

    this.adminService.configurePayroll(this.payrollConfig).subscribe({
      next: (response) => {
        this.successMessage = 'Payroll configuration saved successfully!';
        this.loadExistingConfigs(); // Refresh the list
        this.resetForm();
      },
      error: (error) => {
        console.error('Error configuring payroll:', error);
        this.errorMessage = 'Failed to save payroll configuration';
      }
    });
  }

  private resetForm(): void {
    this.payrollConfig = {
      roles: '',
      salary: 0,
      hraPercent: 0,
      pfPercent: 0,
      bonusPercent: 0,
      specialAllowancePercent: 0,
      professionalTax: 0
    };
  }

  logout(): void {
    this.adminService.logout();
  }
}