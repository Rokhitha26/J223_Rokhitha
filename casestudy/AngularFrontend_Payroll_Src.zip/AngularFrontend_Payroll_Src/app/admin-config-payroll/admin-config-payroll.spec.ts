import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminConfigPayroll } from './admin-config-payroll';

describe('AdminConfigPayroll', () => {
  let component: AdminConfigPayroll;
  let fixture: ComponentFixture<AdminConfigPayroll>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminConfigPayroll]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminConfigPayroll);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
