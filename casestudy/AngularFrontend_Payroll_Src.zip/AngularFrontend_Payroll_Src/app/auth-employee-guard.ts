import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { Employeeservice } from './employeeservice';

export const authEmployeeGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const employeeService = inject(Employeeservice);

  if (employeeService.isAuthenticated()) {
    return true;
  } else {
    router.navigate(['/employee-login']);
    return false;
  }
};
