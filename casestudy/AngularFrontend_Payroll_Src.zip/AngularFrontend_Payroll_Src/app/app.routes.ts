import { Routes } from '@angular/router';
import { AdminLogin } from './admin-login/admin-login';
import { AuthGuard } from './auth-guard';
import { AdminDashboard} from './admin-dashboard/admin-dashboard';
import { AdminAddEmployee} from './admin-add-employee/admin-add-employee';
import { AdminConfigPayroll } from './admin-config-payroll/admin-config-payroll';
import { AdminDeleteEmployee } from './admin-delete-employee/admin-delete-employee';
import { AdminUpdateEmployee } from './admin-update-employee/admin-update-employee';
import { AdminPayrollByDate } from './get-payroll-by-date/get-payroll-by-date';
import { GetAllEmployee } from './get-all-employee/get-all-employee';
import { authManagerGuard } from './auth-manager-guard';
import { MgrLeaveApproval } from './mgr-leave-approval/mgr-leave-approval';
import { MgrShowPending } from './mgr-show-pending/mgr-show-pending';
import { LoginDashboard } from './login-dashboard/login-dashboard';
import {EmployeeLogin} from './employee-login/employee-login';
import { ManagerLogin } from './manager-login/manager-login';
import { PayrollInitiate } from './payroll-initiate/payroll-initiate';
import { EmployeeDashboard } from './employee-dashboard/employee-dashboard';
import { authEmployeeGuard } from './auth-employee-guard';
import { EmpApplyLeave } from './emp-apply-leave/emp-apply-leave';
import { EmpGetLeaves } from './emp-get-leaves/emp-get-leaves';
import { EmpGetPayrolls } from './emp-get-payrolls/emp-get-payrolls';
import { EmpUpdateProfile } from './emp-update-profile/emp-update-profile';
import { ManagerDashboard } from './manager-dashboard/manager-dashboard';
export const routes: Routes = [
  { path: '', component: LoginDashboard },
  { path: 'login-dashboard', component: LoginDashboard },
  { path: 'admin/login', component: AdminLogin },
  { path: 'employee/login', component: EmployeeLogin },
  { path: 'manager/login', component: ManagerLogin },
{ path: 'employee-login', redirectTo: 'employee/login', pathMatch: 'full' },

  {
    path: 'admin/dashboard',
    component: AdminDashboard,
    canActivate: [AuthGuard],
    children: [
      { path: 'add-employee', component: AdminAddEmployee },
      { path: 'config-payroll', component: AdminConfigPayroll },
      { path: 'delete-employee', component: AdminDeleteEmployee },
      { path: 'update-employee', component: AdminUpdateEmployee },
      { path: 'payroll-by-date', component: AdminPayrollByDate },
      { path: 'get-all-employee', component: GetAllEmployee },
      { path: 'payroll-initiate', component: PayrollInitiate }
    ]
  },
  {
    path: 'manager/dashboard',
    component: ManagerDashboard,
    canActivate: [authManagerGuard],
    children: [
      { path: 'leave-approval', component: MgrLeaveApproval },
      { path: 'show-pending', component: MgrShowPending }
    ]
  },
   {
    path: 'employee/dashboard',
    component: EmployeeDashboard,
    canActivate: [authEmployeeGuard],
    children: [
      { path: 'apply-leave', component: EmpApplyLeave },
      { path: 'get-leaves', component: EmpGetLeaves },
      { path: 'get-payrolls', component: EmpGetPayrolls },
      { path: 'update-profile', component: EmpUpdateProfile }
    ]
  }
];
