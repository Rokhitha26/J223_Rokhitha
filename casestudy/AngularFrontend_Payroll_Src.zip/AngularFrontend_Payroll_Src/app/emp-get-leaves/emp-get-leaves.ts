import { Component, OnInit } from '@angular/core';
import { Employeeservice } from '../employeeservice';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
@Component({
  selector: 'app-emp-get-leaves',
  templateUrl: './emp-get-leaves.html',
  styleUrls: ['./emp-get-leaves.css'],
  imports:[CommonModule,FormsModule,RouterModule,MatTableModule,MatCardModule,MatProgressSpinnerModule]
})
export class EmpGetLeaves implements OnInit {
  leaveRecords: any[] = [];
  errorMessage: string = '';

  constructor(private employeeService: Employeeservice) {}
displayedColumns: string[] = ['startDate', 'endDate', 'leaveType', 'reason', 'status'];

  ngOnInit(): void {
    const empId = localStorage.getItem('empId');
    if (empId) {
      this.employeeService.getLeaveRecords(+empId).subscribe({
        next: (data) => {
          this.leaveRecords = data;
        },
        error: (err) => {
          this.errorMessage = 'Failed to fetch leave records.';
          console.error(err);
        }
      });
    } else {
      this.errorMessage = 'Employee ID not found in local storage.';
    }
  }
}
