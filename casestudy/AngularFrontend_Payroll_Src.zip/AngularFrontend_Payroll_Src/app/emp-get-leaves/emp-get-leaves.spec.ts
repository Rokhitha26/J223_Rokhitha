import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpGetLeaves } from './emp-get-leaves';

describe('EmpGetLeaves', () => {
  let component: EmpGetLeaves;
  let fixture: ComponentFixture<EmpGetLeaves>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmpGetLeaves]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpGetLeaves);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
