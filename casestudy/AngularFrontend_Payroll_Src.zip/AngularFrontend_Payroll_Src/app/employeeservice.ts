import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Employeeservice {
  private static TOKEN_KEY = 'employee-token';
  private baseUrl = 'http://localhost:8080/api/employee';

  constructor(private http: HttpClient) { }

  // ---------- TOKEN ----------
  static getToken(): string | null {
    return localStorage.getItem(Employeeservice.TOKEN_KEY);
  }
// Add this method to your existing Employeeservice
getCurrentEmployeeId(): number {
  return parseInt(localStorage.getItem('empId') || '-1', 10);
}

getCurrentEmployeeGender(): string {
  return localStorage.getItem('empGender') || '';
}

  static setToken(token: string): void {
    localStorage.setItem(Employeeservice.TOKEN_KEY, token);
  }

 logoutAndRedirect(router: Router): void {
  localStorage.removeItem(Employeeservice.TOKEN_KEY);
  router.navigate(['']);
}


  isAuthenticated(): boolean {
    return !!Employeeservice.getToken();
  }
getDecodedToken(): any {
  const token = Employeeservice.getToken();
  if (!token) return null;

  const payload = token.split('.')[1];
  return JSON.parse(atob(payload));
}

getEmployeeIdFromToken(): number {
  const decoded = this.getDecodedToken();
  return decoded?.employeeId;
}

getGenderFromToken(): string {
  const decoded = this.getDecodedToken();
  return decoded?.gender;
}

  // ---------- LOGIN ----------
  login(email: string, password: string) {
    const url = `${this.baseUrl}/login`;
    return this.http.post<any>(url, null, {
      params: { email, password }
    });
  }

  // ---------- UPDATE PROFILE ----------


  // ---------- APPLY LEAVE ----------
// In your Employeeservice
  applyLeave(leaveData: any): Observable<any> {
    const token = localStorage.getItem('empToken');
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });

    return this.http.post(`${this.baseUrl}/applyLeave`, leaveData, { headers, responseType: 'text' });
  }

  // ---------- GET PAYROLLS ----------

getLeaveRecords(empId: number): Observable<any[]> {
  return this.http.get<any[]>(`http://localhost:8080/api/employee/${empId}/leaves`);
}
getPayrolls(empId: number): Observable<any[]> {
  return this.http.get<any[]>(`${this.baseUrl}/${empId}/payrolls`);
}
updateOwnProfile(empId: number, updateData: any): Observable<any> {
  return this.http.put(`${this.baseUrl}/updateProfile/${empId}`, updateData);
}
getEmployeeById(empId: number): Observable<any> {
  return this.http.get(`${this.baseUrl}/profile/${empId}`);
}

  // ---------- GET LEAVES ----------
  getLeaves(empId: number) {
    const url = `${this.baseUrl}/${empId}/leaves`;
    return this.http.get(url);
  }
}
