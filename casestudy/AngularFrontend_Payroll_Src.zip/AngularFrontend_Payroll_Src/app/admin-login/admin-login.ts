import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Adminservice } from '../adminservice'; 

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterModule],
  templateUrl: './admin-login.html',
  styleUrls: ['./admin-login.css']
})
export class AdminLogin {
  email: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(
    private adminService: Adminservice,
    private router: Router
  ) {}

  onSubmit(): void {
    this.errorMessage = '';
    
    this.adminService.loginAdmin(this.email, this.password).subscribe({
      next: (response) => {
        // Successful login - navigate to dashboard
        this.router.navigate(['/admin/dashboard']);
      },
      error: (error) => {
        this.errorMessage = 'Invalid credentials. Please try again.';
        console.error('Login error:', error);
      }
    });
  }
}