import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDeleteEmployee } from './admin-delete-employee';

describe('AdminDeleteEmployee', () => {
  let component: AdminDeleteEmployee;
  let fixture: ComponentFixture<AdminDeleteEmployee>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminDeleteEmployee]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminDeleteEmployee);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
