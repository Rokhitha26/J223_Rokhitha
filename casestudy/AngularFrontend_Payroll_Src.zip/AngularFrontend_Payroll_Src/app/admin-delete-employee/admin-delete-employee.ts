import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Adminservice } from '../adminservice';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-delete-employee',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-delete-employee.html',
  styleUrls: ['./admin-delete-employee.css']
})
export class AdminDeleteEmployee {
  employeeId: number | null = null;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(
    private adminService: Adminservice,
    private router: Router
  ) {}

  onSubmit(): void {
    this.successMessage = '';
    this.errorMessage = '';

    if (!this.employeeId) {
      this.errorMessage = 'Please enter a valid employee ID';
      return;
    }

    this.adminService.deleteEmployee(this.employeeId).subscribe({
      next: () => {
        this.successMessage = `Employee with ID ${this.employeeId} deleted successfully!`;
        this.resetForm();
      },
      error: (error) => {
        console.error('Error deleting employee:', error);
        this.errorMessage = error.status === 404 
          ? `Employee with ID ${this.employeeId} not found`
          : 'Failed to delete employee. Please try again.';
      }
    });
  }

  private resetForm(): void {
    this.employeeId = null;
  }

  logout(): void {
    this.adminService.logout();
  }
}